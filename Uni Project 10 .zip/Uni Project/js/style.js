// jQuery(document).ready(function ($) {

//     $('#checkbox').change(function(){
//       setInterval(function () {
//           moveRight();
//       }, 4500);
//     });

//       var slideCount = $('#slider ul li').length;
//       var slideWidth = $('#slider ul li').width();
//       var slideHeight = $('#slider ul li').height();
//       var sliderUlWidth = slideCount * slideWidth;

//       $('#slider').css({ width: slideWidth, height: slideHeight });

//       $('#slider ul').css({ width: sliderUlWidth, marginLeft: - slideWidth });

//       $('#slider ul li:last-child').prependTo('#slider ul');

//       function moveLeft() {
//           $('#slider ul').animate({
//               left: + slideWidth
//           }, 200, function () {
//               $('#slider ul li:last-child').prependTo('#slider ul');
//               $('#slider ul').css('left', '');
//           });
//       };

//       function moveRight() {
//           $('#slider ul').animate({
//               left: - slideWidth
//           }, 200, function () {
//               $('#slider ul li:first-child').appendTo('#slider ul');
//               $('#slider ul').css('left', '');
//           });
//       };

//       $('a.control_prev').click(function () {
//           moveLeft();
//       });

//       $('a.control_next').click(function () {
//           moveRight();
//       });

//   });    



// Swiper part

const swiper = new Swiper('.swiper-container', {

  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },

  autoplay: {
    delay: 2000,
  },
  loop: true,

  // Default parameters
  slidesPerView: 1,
  spaceBetween: 10,
  centeredSlides: true,
  roundLengths: true,
  loop: true,
  loopAdditionalSlides: 30,
  breakpoints: {
    320: {
      slidesPerView: 1,
      spaceBetween: 0
    },
    480: {
      slidesPerView: 2,
      spaceBetween: 0
    },
    640: {
      slidesPerView: 3,
      spaceBetween: 0
    }
  }
});

// Swiper part end


// const faders = document.querySelectorAll = ('.fadeingIn');

// const appearOptions = {
//   threshold: 1;
// };

// const appearOnScroll = new IntersectionObserver(function (
//     entries,
//     appearOnScroll
//   ) {
//     entries.forEach(entry => {
//       if (!entry.isIntersecting) {

//       } else {
//         entry.target.classList.add('appear');
//         appearOnScroll.unobserve(entry.target);
//       }
//     })
//   },
//   appearOptions);

//   faders.forEach(fader => {
//   appearOnScroll.observe(fader);
// });


// const progress = document.querySelector('scroll', () => {
//   const winScroll = window.pageYOffset;
//   const height = document.documentElement.scrollHeight;
//   console.log(height)

// })


// alert( window.innerWidth ); // full window width
// alert( document.documentElement.clientWidth ); // window width minus the scrollbar


window.addEventListener('scroll',function(){
  if((window.scrollY >500) && (window.scrollY <600)){
    console.log('ok');
  }
})




var mybutton = document.getElementById("myBtn");

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}